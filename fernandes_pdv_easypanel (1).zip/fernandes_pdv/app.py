import os
from datetime import datetime, date
from decimal import Decimal
from io import BytesIO

from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-change-me')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///fernandes_pdv.db').replace('postgres://', 'postgresql://')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), default='vendedor')
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Supplier(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False)
    document = db.Column(db.String(40))
    phone = db.Column(db.String(40))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False)
    sku = db.Column(db.String(80), unique=True)
    cost_price = db.Column(db.Numeric(10,2), default=0)
    sale_price = db.Column(db.Numeric(10,2), default=0)
    stock = db.Column(db.Integer, default=0)
    min_stock = db.Column(db.Integer, default=5)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Purchase(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    supplier_id = db.Column(db.Integer, db.ForeignKey('supplier.id'))
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    purchase_date = db.Column(db.Date, default=date.today)
    quantity = db.Column(db.Integer, nullable=False)
    unit_cost = db.Column(db.Numeric(10,2), nullable=False)
    total = db.Column(db.Numeric(10,2), nullable=False)
    note = db.Column(db.String(255))
    supplier = db.relationship('Supplier')
    product = db.relationship('Product')

class Sale(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    sale_date = db.Column(db.DateTime, default=datetime.utcnow)
    customer = db.Column(db.String(180), default='Cliente balcão')
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Numeric(10,2), nullable=False)
    total = db.Column(db.Numeric(10,2), nullable=False)
    payment_method = db.Column(db.String(40), default='Dinheiro')
    product = db.relationship('Product')
    user = db.relationship('User')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def money(v):
    return f"R$ {float(v or 0):,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
app.jinja_env.filters['money'] = money

def admin_required():
    if current_user.role != 'admin':
        flash('Acesso permitido apenas para administrador.', 'error')
        return False
    return True

@app.before_request
def setup_database():
    db.create_all()
    email = os.getenv('ADMIN_EMAIL', 'admin@fernandestecnologia.com')
    password = os.getenv('ADMIN_PASSWORD', '123456')
    if not User.query.filter_by(email=email).first():
        admin = User(name='Administrador', email=email, role='admin')
        admin.set_password(password)
        db.session.add(admin)
        db.session.commit()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(email=request.form['email']).first()
        if user and user.active and user.check_password(request.form['password']):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Email ou senha inválidos.', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/')
@login_required
def dashboard():
    today = date.today()
    sales_today = Sale.query.filter(db.func.date(Sale.sale_date) == today).all()
    purchases_today = Purchase.query.filter(Purchase.purchase_date == today).all()
    total_sales = sum([s.total for s in sales_today], Decimal('0'))
    total_purchases = sum([p.total for p in purchases_today], Decimal('0'))
    products = Product.query.count()
    low_stock = Product.query.filter(Product.stock <= Product.min_stock).count()
    recent_sales = Sale.query.order_by(Sale.sale_date.desc()).limit(8).all()
    return render_template('dashboard.html', total_sales=total_sales, total_purchases=total_purchases, products=products, low_stock=low_stock, recent_sales=recent_sales)

@app.route('/produtos', methods=['GET', 'POST'])
@login_required
def products():
    if request.method == 'POST':
        p = Product(name=request.form['name'], sku=request.form.get('sku') or None,
                    cost_price=Decimal(request.form.get('cost_price') or '0'), sale_price=Decimal(request.form.get('sale_price') or '0'),
                    stock=int(request.form.get('stock') or 0), min_stock=int(request.form.get('min_stock') or 5))
        db.session.add(p); db.session.commit(); flash('Produto cadastrado.', 'success')
        return redirect(url_for('products'))
    return render_template('products.html', products=Product.query.order_by(Product.name).all())

@app.route('/fornecedores', methods=['GET', 'POST'])
@login_required
def suppliers():
    if request.method == 'POST':
        s = Supplier(name=request.form['name'], document=request.form.get('document'), phone=request.form.get('phone'))
        db.session.add(s); db.session.commit(); flash('Fornecedor cadastrado.', 'success')
        return redirect(url_for('suppliers'))
    return render_template('suppliers.html', suppliers=Supplier.query.order_by(Supplier.name).all())

@app.route('/compras', methods=['GET', 'POST'])
@login_required
def purchases():
    if request.method == 'POST':
        product = Product.query.get(int(request.form['product_id']))
        qty = int(request.form['quantity']); cost = Decimal(request.form['unit_cost'])
        product.stock += qty; product.cost_price = cost
        purchase = Purchase(supplier_id=int(request.form['supplier_id']), product_id=product.id,
                            purchase_date=datetime.strptime(request.form['purchase_date'], '%Y-%m-%d').date(),
                            quantity=qty, unit_cost=cost, total=qty*cost, note=request.form.get('note'))
        db.session.add(purchase); db.session.commit(); flash('Compra lançada e estoque atualizado.', 'success')
        return redirect(url_for('purchases'))
    return render_template('purchases.html', purchases=Purchase.query.order_by(Purchase.purchase_date.desc()).all(), products=Product.query.all(), suppliers=Supplier.query.all())

@app.route('/vendas', methods=['GET', 'POST'])
@login_required
def sales():
    if request.method == 'POST':
        product = Product.query.get(int(request.form['product_id']))
        qty = int(request.form['quantity'])
        if product.stock < qty:
            flash('Estoque insuficiente para esta venda.', 'error'); return redirect(url_for('sales'))
        price = Decimal(request.form.get('unit_price') or product.sale_price)
        product.stock -= qty
        sale = Sale(product_id=product.id, user_id=current_user.id, customer=request.form.get('customer') or 'Cliente balcão',
                    quantity=qty, unit_price=price, total=qty*price, payment_method=request.form.get('payment_method') or 'Dinheiro')
        db.session.add(sale); db.session.commit(); flash('Venda lançada com sucesso.', 'success')
        return redirect(url_for('receipt', sale_id=sale.id))
    return render_template('sales.html', sales=Sale.query.order_by(Sale.sale_date.desc()).all(), products=Product.query.order_by(Product.name).all())

@app.route('/comprovante/<int:sale_id>.pdf')
@login_required
def receipt(sale_id):
    sale = Sale.query.get_or_404(sale_id)
    buffer = BytesIO(); c = canvas.Canvas(buffer, pagesize=A4); w, h = A4
    y = h - 30*mm
    c.setFont('Helvetica-Bold', 18); c.drawString(25*mm, y, 'Fernandes Tecnologia'); y -= 10*mm
    c.setFont('Helvetica', 10); c.drawString(25*mm, y, 'Comprovante de Venda / PDV'); y -= 12*mm
    c.line(25*mm, y, 185*mm, y); y -= 10*mm
    c.setFont('Helvetica', 11)
    lines = [f'Venda Nº: {sale.id}', f'Data: {sale.sale_date.strftime("%d/%m/%Y %H:%M")}', f'Cliente: {sale.customer}',
             f'Produto: {sale.product.name}', f'Quantidade: {sale.quantity}', f'Valor unitário: {money(sale.unit_price)}',
             f'Pagamento: {sale.payment_method}', f'Total: {money(sale.total)}', f'Vendedor: {sale.user.name}']
    for line in lines:
        c.drawString(25*mm, y, line); y -= 8*mm
    c.line(25*mm, y, 185*mm, y); y -= 10*mm
    c.setFont('Helvetica-Oblique', 10); c.drawString(25*mm, y, 'Obrigado pela preferência!')
    c.showPage(); c.save(); buffer.seek(0)
    return send_file(buffer, mimetype='application/pdf', as_attachment=True, download_name=f'comprovante-venda-{sale.id}.pdf')

@app.route('/usuarios', methods=['GET', 'POST'])
@login_required
def users():
    if not admin_required(): return redirect(url_for('dashboard'))
    if request.method == 'POST':
        u = User(name=request.form['name'], email=request.form['email'], role=request.form.get('role','vendedor'))
        u.set_password(request.form['password'])
        db.session.add(u); db.session.commit(); flash('Usuário cadastrado.', 'success')
        return redirect(url_for('users'))
    return render_template('users.html', users=User.query.order_by(User.name).all())

@app.route('/relatorios')
@login_required
def reports():
    sales_all = Sale.query.order_by(Sale.sale_date.desc()).limit(100).all()
    total = sum([s.total for s in sales_all], Decimal('0'))
    return render_template('reports.html', sales=sales_all, total=total)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
