# Fernandes Tecnologia - PDV Profissional

Sistema PDV em Flask com login multiusuário, produtos, fornecedores, compras, vendas, estoque e comprovante em PDF.

## Rodar localmente
```bash
pip install -r requirements.txt
python app.py
```
Acesse: http://localhost:5000

Login inicial:
- Email: admin@fernandestecnologia.com
- Senha: 123456

## EasyPanel
Use Dockerfile.
Variáveis recomendadas:
- SECRET_KEY
- DATABASE_URL
- ADMIN_EMAIL
- ADMIN_PASSWORD

Porta: 5000
